"""
URL configuration for fintech project.

The urlpatterns list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

from django.urls import include

urlpatterns = [
    path('api/', include('accounts.urls')),  # Replace 'your_app' with your actual app name
]



app_name = 'fintech'  # Namespace to prevent conflicts

urlpatterns = [
    

    # Admin Panel
    path('admin/', admin.site.urls),

    # Include accounts app URLs
    # path('accounts/', include('accounts.urls')),
    path('', include('accounts.urls')), 

    # Django built-in auth views (login, logout, password reset, etc.),
    path('accounts/', include('django.contrib.auth.urls')),

    # Root path redirect (choose one)
    path('', RedirectView.as_view(pattern_name=''), name='registration'),  # Redirect to login page
    # OR serve a home template instead
    # path('', TemplateView.as_view(template_name='home.html'), name='home'),
]




# http://127.0.0.1:8000/




