from django.apps import AppConfig
from django.db import models
from django.db.models.signals import post_migrate
import logging

logger = logging.getLogger(__name__)

def update_logentry_model(sender, **kwargs):
    """Safely patch LogEntry after migrations"""
    from django.contrib.admin.models import LogEntry
    from django.contrib.contenttypes.models import ContentType

    try:
        user_model = ContentType.objects.get(
            app_label='accounts',
            model='customuser'
        ).model_class()

        if not hasattr(LogEntry, 'user'):
            field = models.ForeignKey(
                user_model,
                on_delete=models.CASCADE,
                related_name='admin_logentries',
                null=True
            )
            field.contribute_to_class(LogEntry, 'user')
            logger.info("Successfully patched LogEntry model")

    except Exception as e:
        logger.error(f"LogEntry patching failed: {str(e)}")

class AccountsConfig(AppConfig):
    name = 'accounts'
    default_auto_field = 'django.db.models.BigAutoField'

    def ready(self):
        # Connect signal after migrations complete
        post_migrate.connect(update_logentry_model, sender=self)
        
        # Development environment check
        try:
            from django.conf import settings
            if settings.DEBUG:
                self._verify_patching()
        except ImportError:
            pass

    def _verify_patching(self):
        """Development-mode verification"""
        try:
            from django.contrib.admin.models import LogEntry
            assert hasattr(LogEntry, 'user')
            logger.debug("LogEntry patch verification successful")
        except AssertionError:
            logger.warning("LogEntry patch verification failed")
        except Exception as e:
            logger.error(f"Verification error: {str(e)}")
