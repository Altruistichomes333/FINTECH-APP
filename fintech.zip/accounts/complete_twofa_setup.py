# Add these imports
from django.http import JsonResponse
from django.views import View
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_POST
from django.core.exceptions import ObjectDoesNotExist
import pyotp

from fintech.accounts.models import TwoFactorModel



@method_decorator(csrf_protect, name='dispatch') # type: ignore
@method_decorator(require_POST, name='dispatch')
class SetupComplete(LoginRequiredMixin, View):
    login_url = 'login'@method_decorator(csrf_protect, name='dispatch')
@method_decorator(require_POST, name='dispatch')
class SetupComplete(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request):
        try:
            user_2fa = TwoFactorModel.objects.get(user=request.user)
            if not user_2fa.twofacode:
                return JsonResponse(
                    {"error": "2FA not initialized. Generate secret first."},
                    status=400
                )

            otp_token = request.POST.get('otp_token', '').strip()
            if not otp_token:
                return JsonResponse({"error": "OTP token required"}, status=400)

            totp = pyotp.TOTP(user_2fa.twofacode)
            if totp.verify(otp_token, valid_window=1):  # Allow 30-second window
                user_2fa.is_twofa_enabled = True
                user_2fa.save()
                # Update session after successful 2FA enablement
                request.session["2fa_verified"] = True
                return JsonResponse({"success": "2FA successfully enabled"}, status=200)
                
            return JsonResponse({"error": "Invalid or expired OTP"}, status=400)
            
        except ObjectDoesNotExist:
            return JsonResponse({"error": "2FA configuration not found"}, status=404)
        except pyotp.PyOTPError as e:
            return JsonResponse({"error": f"OTP validation error: {str(e)}"}, status=400)

