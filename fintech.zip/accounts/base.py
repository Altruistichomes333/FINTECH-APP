# # accounts/base.py
# from django.db import models
# from django.contrib.auth.models import AbstractUser

# class CustomUser(AbstractUser):
#     # Your fields here
#     id = ShortUUIDField(
#         primary_key=True,
#         unique=True,
#         editable=False,
#     )
#     username = models.CharField(max_length=200)
#     phone = models.CharField(max_length=20, unique=True)
#     email = models.EmailField(max_length=254, unique=True)


# class UserProfile(models.Model):
#     user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
#     # Additional fields here
