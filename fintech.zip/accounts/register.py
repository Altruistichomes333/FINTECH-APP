
from django.views import View
from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.http import JsonResponse
from .models import CustomUser, UserProfile
from django.contrib import messages
from django.contrib.auth.hashers import make_password






def register(request):
    if request.method == 'POST':
        phone = request.POST.get('phone')
        
        # Check if the phone number already exists
        if CustomUser.objects.filter(phone=phone).exists():
            messages.error(request, 'This phone number is already registered.')
            return redirect('register')  # Return an HttpResponse here
        
        # Continue with user registration logic
        # For example:
        # user = CustomUser.objects.create(...)
        # user.save()
        messages.success(request, 'Registration successful!')
        return redirect('login')  # Ensure this returns an HttpResponse

    # If it's a GET request, render the registration form
    return render(request, 'registration/register.html')  # Ensure this returns an HttpResponse











class RegisterView(View):
    def get(self, request):
        return render(request, 'register.html')
    
    def post(self, request):
        username = request.POST.get('username')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')
        account_type = request.POST.get('account_type', 'personal')
        
        if not all([username, phone, email, password, password2]):
            return JsonResponse({'error': 'All fields are required'}, status=400)
        
        from django.contrib import messages
from django.shortcuts import render, redirect


 
    
        
def register(request):
    # Other registration logic
    if password1 != password2:
        return JsonResponse({'error': 'Passwords do not match'}, status=400)
    # Continue with registration
def register(request):
    if CustomUser.objects.filter(username=username).exists():
        return JsonResponse({'error': 'Username already exists'}, status=400)
def register(request):
    if CustomUser.objects.filter(email=email).exists():
        return JsonResponse({'error': 'Email already registered'}, status=400)
def register(request):    
    user = CustomUser.objects.create_user(username=username, email=email, phone=phone, password=password)
        
    UserProfile.objects.create(user=user, phone=phone, account_type=account_type)
def register(request):
    login(request, user)
    return JsonResponse({'success': 'Registration successful'}, status=200)
def register(request):
    messages.success(request, "Registration successful. You can now log in.")
    return redirect('login')  # Redirect to login page after successful registration








import logging

logger = logging.getLogger(__name__)

def register(request):
    if request.method == 'POST':
        # Your existing logic...
        logger.debug("POST request received")
        # More logic...
    else:
        logger.debug("GET request received")
        return render(request, 'registration/register.html')













# from django.views import View
# from django.contrib import messages
# from django.shortcuts import render, redirect
# from django.http import JsonResponse
# from accounts.models import CustomUser


# class RegisterView(View):
#     def get(self, request):
#         # Handle GET request
#         return render(request, 'registration/register.html')

#     def post(self, request):
#         # Handle POST request
#         # Your registration logic here
#         return redirect('login')

# def register(request):
#     if request.method == 'POST':
#         username = request.POST.get('username')
#         password1 = request.POST.get('password1')
#         password2 = request.POST.get('password2')

#         if password1 != password2:
#             return JsonResponse({'error': 'Passwords do not match'}, status=400)

#         if CustomUser.objects.filter(username=username).exists():
#             messages.error(request, 'Username is already taken.')
#             return redirect('register')

#         user = CustomUser(username=username)
#         user.set_password(password1)  # Hash the password
#         user.save()

#         messages.success(request, 'Registration successful!')
#         return redirect('login')

#     # For GET requests, render the registration form
#     return render(request, 'registration/register.html')






from django.core.mail import send_mail

send_mail(
    'HBD',
    'congratulations',
    'israelium33@gmail.com',  # Sender's email
    ['altruistic7154@gmail.com'],  # List of recipients
    fail_silently=False,
)
