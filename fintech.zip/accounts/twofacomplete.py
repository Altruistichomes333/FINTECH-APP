from django.shortcuts import render
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from django.http import JsonResponse
from .models import TwofactorModel
import pyotp
from django.contrib.auth.mixins import LoginRequiredMixin
# Add these imports
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.http import require_POST
from django.core.exceptions import ObjectDoesNotExist




class SetupComplete(LoginRequiredMixin,View):
    login_url ='login'
    def post(self,request):
        login_user = request.user
        user_2fa  = TwofactorModel.objects.get_or_create(user=login_user)[0]
        twofacode = user_2fa.twofacode

        if not twofacode:
            return JsonResponse({"error": "TOTP secret not found."}, status=400)
        

        otp_token =  request.POST.get('otp_token')
        totp_code = pyotp.TOTP(twofacode)
        if totp_code.verify(otp_token):
            user_2fa.is_twofa_enabled = True
            user_2fa.save()
            return JsonResponse({"success": "2FA setup complete."}, status=200)
        else:
            return JsonResponse({"error": "Invalid OTP token."}, status=400)



        
        




        # @method_decorator(csrf_protect, name='dispatch')
@method_decorator(require_POST, name='dispatch')
class SetupComplete(LoginRequiredMixin, View):
    login_url = 'login'
    
    def post(self, request):
        try:
            user_2fa = TwofactorModel.objects.get(user=request.user)
            if not user_2fa.twofacode:
                return JsonResponse(
                    {"error": "2FA not initialized. Generate secret first."},
                    status=400
                )

            otp_token = request.POST.get('otp_token', '').strip()
            if not otp_token:
                return JsonResponse({"error": "OTP token required"}, status=400)

            totp = pyotp.TOTP(user_2fa.twofacode)
            if totp.verify(otp_token, valid_window=1):  # Allow 30-second window
                user_2fa.is_twofa_enabled = True
                user_2fa.save()
                # Update session after successful 2FA enablement
                request.session["2fa_verified"] = True
                return JsonResponse({"success": "2FA successfully enabled"}, status=200)
                
            return JsonResponse({"error": "Invalid or expired OTP"}, status=400)
            
        except ObjectDoesNotExist:
            return JsonResponse({"error": "2FA configuration not found"}, status=404)
        except pyotp.PyOTPError as e:
            return JsonResponse({"error": f"OTP validation error: {str(e)}"}, status=400)



