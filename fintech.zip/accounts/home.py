

from django.shortcuts import render, redirect
from django.views.generic import View
from django.http import JsonResponse
from django.views.generic import TemplateView



# class HomepageView(View):
#     def get(self, request):
#         return render(request, 'home/index.html')
    
    




class HomepageView(TemplateView):
    template_name = 'home/index.html'  # Update this path


