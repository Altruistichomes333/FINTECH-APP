from django.views import View
from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone
# from django.contrib.auth.models import CustomUser
# Correct relative import
from .mailer_otpsender import send_otp  # Dot prefix for same package








from .models import OTPCode
from .mailer_otpsender import send_otp
class Email_verification(View):
    def get(self, request):
        return render(request, 'otpverify.html')

    def post(self, request): 
        otp_user = request.POST.get('otp_code')
        if not otp_user:
            return JsonResponse({'error': "Verification code is not provided"}, status=400)
        
        try:
            user_otp_record = OTPCode.objects.get(email_otp=otp_user)
            user = user_otp_record.user  # Get the user linked to OTP

            # Check if OTP is expired
            if user_otp_record.is_otp_expired():
                send_otp(user.email)
                return JsonResponse({"error": "Code expired. A new code has been sent to your mail"}, status=400)

            # Check if email is already verified
            if user.email_verified:
                return JsonResponse({"error": "Email already verified"}, status=400)

            # Verify email
            user.email_verified = True
            user.save()

            # Optionally, delete the OTP record or mark it as used
            # user_otp_record.delete()

            return JsonResponse({'success': "Email verified successfully"}, status=200)

        except OTPCode.DoesNotExist:
            return JsonResponse({'error': "Invalid verification code"}, status=400)
