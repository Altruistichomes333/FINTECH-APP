import pyotp
from django.utils import timezone
from django.http import JsonResponse
from django.views import View
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from .models import TwoFactorAuth
import json



class Verify2faToken(View):  # Ensure the class name matches
    # Your verification logic here
    pass


class Generate2FAKeyView(View):
    @method_decorator(login_required)
    def post(self, request):
        user = request.user
        two_fa, created = TwoFactorAuth.objects.get_or_create(user=user)
        
        if not two_fa.secret_key:
            two_fa.generate_secret_key()
            two_fa.save()
        
        return JsonResponse({'secret_key': two_fa.secret_key}, status=200)


class Verify2FAView(View):
    @method_decorator(login_required)
    def post(self, request):
        data = json.loads(request.body)
        otp = data.get('otp')
        
        user = request.user
        try:
            two_fa = TwoFactorAuth.objects.get(user=user)
            totp = pyotp.TOTP(two_fa.secret_key)
            
            if totp.verify(otp):
                two_fa.last_used = timezone.now()
                two_fa.save()
                return JsonResponse({'message': '2FA verified successfully'}, status=200)
            else:
                return JsonResponse({'error': 'Invalid 2FA OTP'}, status=400)
        except TwoFactorAuth.DoesNotExist:
            return JsonResponse({'error': '2FA not enabled'}, status=400)


class Disable2FAView(View):
    @method_decorator(login_required)
    def post(self, request):
        user = request.user
        try:
            two_fa = TwoFactorAuth.objects.get(user=user)
            two_fa.delete()
            return JsonResponse({'message': '2FA disabled successfully'}, status=200)
        except TwoFactorAuth.DoesNotExist:
            return JsonResponse({'error': '2FA not enabled'}, status=400)
45