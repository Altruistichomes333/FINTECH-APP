from django.shortcuts import render, redirect
from django.views.generic import View
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.core.exceptions import ValidationError
from django.http import JsonResponse
from django.contrib.auth import authenticate, login
from .mailer_otpsender import send_otp
import pdb




class LoginView(View):
    def get(self, request):
        return render(request, 'home/login.html')

    def post(self, request):
        # Get form data
        email = request.POST.get('email')
        password = request.POST.get('password')
        account_type = request.POST.get('account_type')

        
        if not all([email, password, account_type]):
            return JsonResponse({"error": "All fields are required"}, status=400)

        user = authenticate(request, email=email, password=password)
        

        if user is not None:
            if user.account_type != account_type:
                return JsonResponse({
                    "error": f"You are not allowed to login as a {account_type.capitalize()} Account"
                }, status=400)

            
            if not user.email_verifiied:
               
                send_otp(user.email)
                return JsonResponse({
                    "verify": "Email not verified. A new OTP has been sent to your email."
                }, status=400)
            try:
                user2fa = TwofactorModel.objects.get(user=user)
                if user2fa.is_twofa_enabled:
                    user_session =request.session['user_session'] = user.id
                   
                    return JsonResponse({'twofactor': '2FA verification is required'})
            except TwofactorModel.DoesNotExist:
                pass
           
            login(request, user)
            return JsonResponse({"success": "Login successful"}, status=200)
        
        else:
            return JsonResponse({
                "error": "Invalid email or password"
            }, status=400)
        
    

           



      

            
        

    
        