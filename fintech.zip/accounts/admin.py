from django.contrib import admin

from .models import  CustomUserGroup, CustomUserPermission, PersonalAccount,TwofactorModel, BusinessAccount, OTPCode, TwoFactorAuth, UserGroup








# @admin.register(CustomUser)  # ✅ Register the model
class CustomUserAdmin(admin.ModelAdmin):  # Inherit from ModelAdmin

    
    list_display = ('email', 'username', 'phone', 'is_verified', 'is_staff', 'is_superuser')
    list_filter = ('is_verified', 'is_staff', 'is_superuser', 'account_type')

    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('Personal Info', {'fields': ('username', 'phone', 'account_type')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'phone', 'password1', 'password2'),
        }),
    )

    search_fields = ('email', 'username', 'phone')
    ordering = ('email',)
    filter_horizontal = ()  # ✅ Removed groups and user_permissions




class CustomUserGroupInline(admin.TabularInline):
    model = CustomUserGroup
    extra = 1

class CustomUserPermissionInline(admin.TabularInline):
    model = CustomUserPermission
    extra = 1

class CustomUserGroupAdmin(admin.ModelAdmin):
    list_display = ('user', 'group', 'created_at')

class CustomUserPermissionAdmin(admin.ModelAdmin):
    list_display = ('user', 'permission')

admin.site.register(CustomUserGroup, CustomUserGroupAdmin)
admin.site.register(CustomUserPermission, CustomUserPermissionAdmin)
admin.site.register(PersonalAccount)
admin.site.register(BusinessAccount)
admin.site.register(OTPCode)
admin.site.register(TwoFactorAuth)
admin.site.register(UserGroup)

