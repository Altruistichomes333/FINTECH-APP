from django.db import models
from django.contrib.auth.models import AbstractUser, Group, Permission
from django.utils import timezone
from django.conf import settings
from django.core.mail import send_mail
from shortuuid.django_fields import ShortUUIDField
import pyotp
import secrets




class CustomUser(AbstractUser):
    # Core Identification Fields
    id = ShortUUIDField(
        primary_key=True,
        unique=True,
        editable=False,
    )
    username = models.CharField(max_length=200)
    phone = models.CharField(max_length=20, unique=True, blank=True, null=True)
    email = models.EmailField(max_length=254, unique=True)

    # Verification & Status Flags
    is_verified = models.BooleanField(default=False)
    verification_token = models.CharField(max_length=100, blank=True)
    email_verified = models.BooleanField(default=True)
    phone_verified = models.BooleanField(default=True)

    # Account Configuration
    ACCOUNT_TYPE_CHOICES = [
        ('personal', 'Personal'),
        ('business', 'Business'),
    ]
    account_type = models.CharField(max_length=20, default='basic')  # or whatever default value you want

    
    # account_type = models.CharField(
        # max_length=10,
    # choices=ACCOUNT_TYPE_CHOICES,
    # default='personal'


    # Permissions & Groups (Fixed M2M relationships)
    groups = models.ManyToManyField(
        Group,
        verbose_name='groups',
        blank=True,
        related_name="customuser_groups",
        related_query_name="customuser",
        through='CustomUserGroup'
    )
    user_permissions = models.ManyToManyField(
        Permission,
        verbose_name='user permissions',
        blank=True,
        related_name="customuser_permissions",
        related_query_name="customuser",
        through='CustomUserPermission'
    )

    # System Fields
    created_at = models.DateTimeField(auto_now_add=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)

    # Auth Configuration
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'phone']

    class Meta:
        verbose_name = "User Account"
        verbose_name_plural = "User Accounts"
        swappable = 'AUTH_USER_MODEL'

    def __str__(self):
        return f"{self.username} ({self.email})"

    def send_verification_email(self):
        subject = "Verify Your Email"
        message = f"Your verification code: {self.verification_token}"
        send_mail(subject, message, settings.EMAIL_HOST_USER, [self.email])


class CustomUserGroup(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    group = models.ForeignKey(Group, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = (('user', 'group'),)
        verbose_name = "User Group Membership"
        verbose_name_plural = "User Group Memberships"

    def __str__(self):
        return f"{self.user.username} - {self.group.name}"


class CustomUserPermission(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    permission = models.ForeignKey(Permission, on_delete=models.CASCADE)

    class Meta:
        unique_together = (('user', 'permission'),)

    def __str__(self):
        return f"{self.user.username} - {self.permission.codename}"


class PersonalAccount(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='personal_account'
    )
    date_of_birth = models.DateField()
    image = models.ImageField(
        upload_to='profiles/%Y/%m/%d/',
        null=True,
        blank=True
    )

    def __str__(self):
        return f"{self.user.username}'s Personal Account"


class BusinessAccount(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='business_account'
    )
    established_date = models.DateField()
    company_name = models.CharField(max_length=200)
    registration_number = models.CharField(max_length=50, unique=True)
    business_address = models.TextField()
    logo = models.ImageField(
        upload_to='business_logos/%Y/',
        null=True,
        blank=True
    )

    def __str__(self):
        return f"{self.company_name} ({self.user.email})"


class OTPCode(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="otp_codes"
    )
    email_otp = models.CharField(max_length=6, null=True, blank=True)
    phone_otp = models.CharField(max_length=6, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def is_otp_expired(self):
        return timezone.now() > self.created_at + timezone.timedelta(minutes=10)

    class Meta:
        verbose_name = "OTP Code"
        ordering = ['-created_at']

    def __str__(self):
        return f"OTP for {self.user.email}"


class TwoFactorAuth(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='two_factor'
    )
    is_enabled = models.BooleanField(default=True)
    secret_key = models.CharField(max_length=200)
    backup_codes = models.JSONField(default=list, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    last_used = models.DateTimeField(null=True, blank=True)

    def generate_secret_key(self):
        self.secret_key = pyotp.random_base32()
        self.save()

    def generate_backup_codes(self):
        self.backup_codes = [secrets.token_hex(4) for _ in range(10)]
        self.save()

    class Meta:
        verbose_name = "Two-Factor Authentication"
        verbose_name_plural = "Two-Factor Authentications"

    def __str__(self):
        return f"2FA for {self.user.email}"


class UserGroup(models.Model):
    users = models.ManyToManyField(
        settings.AUTH_USER_MODEL,
        related_name="membership_groups",
        blank=True
    )
    group = models.ForeignKey(
        Group,
        on_delete=models.CASCADE,
        related_name="custom_groups"
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "User Group"
        verbose_name_plural = "User Groups"
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.group.name} Group"



class TwofactorModel(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    secret_key = models.CharField(max_length=16)
    created_at = models.DateTimeField(auto_now_add=True)




class UserProfile(models.Model):
    user = models.OneToOneField(CustomUser, on_delete=models.CASCADE)
    phone = models.CharField(max_length=15)  # Ensure this line exists
    account_type = models.CharField(max_length=10)  # Example field

    def __str__(self):
        return self.user.username
