from http.client import HTTPResponse
from django.contrib.auth.backends import ModelBackend
from django.contrib.auth import get_user_model

CustomUser = get_user_model()

class EmailAuthBackend(ModelBackend):
    """Authenticate using email instead of username."""
    
    def authenticate(self: HTTPResponse, username=None, password=None, **kwargs):
        try:
            user = CustomUser.objects.get(email=username)
            if user.check_password(password):
                return user
        except CustomUser.DoesNotExist:
            return None
