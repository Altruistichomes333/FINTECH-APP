from django.core.mail import EmailMessage
from django.conf import settings
from django.utils import timezone
import pyotp
from .models import CustomUser, OTPCode
from django.db import transaction
from django.core.exceptions import ObjectDoesNotExist
# Correct relative import

# Constants
OTP_VALID_MINUTES = 10
OTP_RESEND_COOLDOWN = 60  # Seconds

def generate_otp(user):
    # Retrieve or create secret
    otp_record, _ = OTPCode.objects.get_or_create(user=user)
    if not otp_record.secret_key:
        otp_record.secret_key = pyotp.random_base32()
        otp_record.save()
    
    # Time-based OTP with fixed interval
    totp = pyotp.TOTP(
        otp_record.secret_key,
        interval=60 * OTP_VALID_MINUTES,
        digits=6
    )
    return totp.now()

def send_otp(email):
    try:
        with transaction.atomic():
            user = CustomUser.objects.get(email=email)
            otp_record = OTPCode.objects.select_for_update().get(user=user)
            
            # Cooldown check
            if (timezone.now() - otp_record.created_at).total_seconds() < OTP_RESEND_COOLDOWN:
                return {
                    'status': False,
                    'error': f'Resend cooldown: wait {OTP_RESEND_COOLDOWN} seconds'
                }
            
            otp_code = generate_otp(user)
            
            # Update OTP record
            otp_record.email_otp = otp_code
            otp_record.created_at = timezone.now()
            otp_record.is_used = False
            otp_record.save()
            
            # Email composition
            subject = "Your Secure OTP Code"
            body = f"""
            Hello {user.username},
            
            Your verification code is: {otp_code}
            Valid for {OTP_VALID_MINUTES} minutes.
            
            Security Tip: Never share this code with anyone.
            """
            email = EmailMessage(
                subject=subject,
                body=body,
                from_email=settings.EMAIL_HOST_USER,
                to=[email],
                reply_to=[settings.ADMIN_SUPPORT_EMAIL]
            )
            
            # Secure email sending
            try:
                email.send(fail_silently=False)
                return {'status': True}
            except Exception as e:
                # Rollback OTP save if email fails
                transaction.set_rollback(True)
                return {
                    'status': False,
                    'error': f'Email delivery failed: {str(e)}'
                }
                
    except ObjectDoesNotExist:
        return {'status': False, 'error': 'User not registered'}
    except Exception as e:
        return {'status': False, 'error': f'System error: {str(e)}'}

def verify_otp(email, user_otp):
    try:
        user = CustomUser.objects.get(email=email)
        otp_record = OTPCode.objects.get(user=user)
        
        # Expiration check
        if (timezone.now() - otp_record.created_at).total_seconds() > OTP_VALID_MINUTES * 60:
            return {'valid': False, 'error': 'OTP expired'}
        
        # Usage check
        if otp_record.is_used:
            return {'valid': False, 'error': 'OTP already used'}
        
        # Verification logic
        totp = pyotp.TOTP(
            otp_record.secret_key,
            interval=60 * OTP_VALID_MINUTES,
            digits=6
        )
        
        if totp.verify(user_otp):
            otp_record.is_used = True
            otp_record.save()
            return {'valid': True}
        
        return {'valid': False, 'error': 'Invalid OTP'}
        
    except ObjectDoesNotExist:
        return {'valid': False, 'error': 'User not found'}
    except Exception as e:
        return {'valid': False, 'error': f'Verification error: {str(e)}'}