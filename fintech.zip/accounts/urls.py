from .home  import HomepageView
from .register import RegisterView
from .login import LoginView
from django.urls import path
# from .emailverification import Email_verificationView
from .two_fasetup import Setup2Fa
from .verification2fa import Verify2faToken
from  .twofacomplete import SetupComplete
# accounts/urls.py
from .emailverification import Email_verification  # Use the correct class name
from . import views




urlpatterns = [
      

       path('index-4.html', views.redirect_to_home),

       path('', HomepageView.as_view(), name='home'),
       path('register', RegisterView.as_view(), name='register'),
       path('login', LoginView.as_view(), name='login'),
       path('email_verify', Email_verification.as_view(), name='verify'),
]
