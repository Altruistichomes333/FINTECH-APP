import base64
from io import BytesIO
from django.shortcuts import render
from django.views import View
import pyotp
import qrcode
from .models import TwofactorModel
from django.contrib.auth.mixins import LoginRequiredMixin



class Setup2Fa(LoginRequiredMixin,View):
    login_url ='login',
    def get(self, request):
        login_user = request.user
        user_2fa  = TwofactorModel.objects.get_or_create(user=login_user)[0]
        user_2fa.generate_twofactor_secret()

        twofa_url = pyotp.totp.TOTP(user_2fa.twofacode).provisioning_uri(
            name = request.user.username,
            issuer_name='fintech')
        qr = qrcode.QRCode(version=1,box_size=10,border=4,)
        qr.add_data(twofa_url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")

        buffer = BytesIO()
        img.save(buffer, format='PNG')
        qr_code_decode = base64.b64encode(buffer.getvalue()).decode()


        return render(request, "twofactor/setup2fa.html",{'2fa_secret':user_2fa.twofacode,'qr_code_decode':qr_code_decode})

        
    



class TwoFactorSetupStart(LoginRequiredMixin, View):
    def get(self, request):
        user_2fa, created = TwofactorModel.objects.get_or_create(user=request.user)
        if not user_2fa.twofacode:
            # Generate new secret only if not existing
            user_2fa.twofacode = pyotp.random_base32()
            user_2fa.save()
        
        provisioning_uri = pyotp.totp.TOTP(user_2fa.twofacode).provisioning_uri(
            name=request.user.email,
            issuer_name="Your App Name"
        )
        
        return render(request, '2fa_setup.html', {
            'provisioning_uri': provisioning_uri,
            'secret': user_2fa.twofacode
        })
