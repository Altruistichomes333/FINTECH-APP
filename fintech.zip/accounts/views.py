from datetime import timezone
from http import server
from logging.config import listen
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.views import View
from django.core.mail import send_mail
from django.conf import settings
from .models import CustomUser, OTPCode, TwoFactorAuth
import pyotp
import json
import random


from django.shortcuts import redirect

def redirect_to_home(request):
    return redirect('home')  # Assumes 'home' is a valid route name

# accounts/views.py
from django.shortcuts import render


class IndexView(View):
    template_name = 'index.html'

    def get(self, request, *args, **kwargs):
        # Add any context data needed for the template
        context = {
            'page_title': 'Peoples Bank Ltd - Digital Banking Solutions',
            'featured_content': {
                'header': 'The money app for Africans',
                'subheader': 'Make free transfers, enjoy cashless payment options and earn interest on your savings with Kuda.'
            }
        }
        return render(request, self.template_name, context)




# class RegisterUserView(View):
#     def post(self, request):
#         data = json.loads(request.body)
#         username = data.get('username')
#         email = data.get('email')
#         phone = data.get('phone')
#         password = data.get('password')
        
#         if CustomUser.objects.filter(email=email).exists():
#             return JsonResponse({'error': 'Email already in use'}, status=400)
        
#         user = CustomUser.objects.create_user(username=username, email=email, phone=phone, password=password)
#         user.verification_token = str(random.randint(100000, 999999))
#         user.save()
#         user.send_verification_email()
        
#         return JsonResponse({'message': 'User registered. Verify your email.'}, status=201)


# class VerifyEmailView(View):
    def post(self, request):
        data = json.loads(request.body)
        email = data.get('email')
        token = data.get('token')
        
        try:
            user = CustomUser.objects.get(email=email, verification_token=token)
            user.is_verified = True
            user.verification_token = ''  # Clear token after verification
            user.save()
            return JsonResponse({'message': 'Email verified successfully'}, status=200)
        except CustomUser.DoesNotExist:
            return JsonResponse({'error': 'Invalid token or email'}, status=400)


class LoginView(View):
    def post(self, request):
        data = json.loads(request.body)
        email = data.get('email')
        password = data.get('password')
        
        user = authenticate(request, email=email, password=password)
        if user is not None:
            login(request, user)
            return JsonResponse({'message': 'Login successful'}, status=200)
        else:
            return JsonResponse({'error': 'Invalid credentials'}, status=400)


class LogoutView(View):
    @method_decorator(login_required)
    def post(self, request):
        logout(request)
        return JsonResponse({'message': 'Logged out successfully'}, status=200)


class SendOTPView(View):
    def post(self, request):
        data = json.loads(request.body)
        email = data.get('email')
        
        try:
            user = CustomUser.objects.get(email=email)
            otp = str(random.randint(100000, 999999))
            OTPCode.objects.create(user=user, email_otp=otp)
            send_mail("Your OTP Code", f"Your OTP code is: {otp}", settings.EMAIL_HOST_USER, [email])
            return JsonResponse({'message': 'OTP sent successfully'}, status=200)
        except CustomUser.DoesNotExist:
            return JsonResponse({'error': 'User not found'}, status=404)


class VerifyOTPView(View):
    def post(self, request):
        data = json.loads(request.body)
        email = data.get('email')
        otp = data.get('otp')
        
        try:
            user = CustomUser.objects.get(email=email)
            latest_otp = OTPCode.objects.filter(user=user).last()
            if latest_otp and latest_otp.email_otp == otp and not latest_otp.is_otp_expired():
                latest_otp.delete()
                return JsonResponse({'message': 'OTP verified successfully'}, status=200)
            else:
                return JsonResponse({'error': 'Invalid or expired OTP'}, status=400)
        except CustomUser.DoesNotExist:
            return JsonResponse({'error': 'User not found'}, status=404)


class EnableTwoFactorAuthView(View):
    @method_decorator(login_required)
    def post(self, request):
        user = request.user
        
        two_fa, created = TwoFactorAuth.objects.get_or_create(user=user)
        if not two_fa.secret_key:
            two_fa.generate_secret_key()
        
        return JsonResponse({'secret_key': two_fa.secret_key}, status=200)


class VerifyTwoFactorAuthView(View):
    @method_decorator(login_required)
    def post(self, request):
        data = json.loads(request.body)
        otp = data.get('otp')
        
        user = request.user
        try:
            two_fa = TwoFactorAuth.objects.get(user=user)
            totp = pyotp.TOTP(two_fa.secret_key)
            if totp.verify(otp):
                two_fa.last_used = timezone.now()
                two_fa.save()
                return JsonResponse({'message': '2FA verified successfully'}, status=200)
            else:
                return JsonResponse({'error': 'Invalid 2FA OTP'}, status=400)
        except TwoFactorAuth.DoesNotExist:
            return JsonResponse({'error': '2FA not enabled'}, status=400)






def custom_gone_view(request, exception):
    return render(request, '410.html', status=410)
# # accounts/views.py (temporary test)



