# from django.views import View
# from django.shortcuts import render, redirect
# from django.contrib import messages
# from django.contrib.auth.hashers import make_password
# from .models import CustomUser

# class RegisterView(View):
#     def get(self, request):
#         return render(request, 'register.html')  # Render registration form

#     def post(self, request):
#         phone = request.POST.get('phone')
#         username = request.POST.get('username')
#         email = request.POST.get('email')
#         password = request.POST.get('password')

#         # Check if phone number already exists
#         if CustomUser.objects.filter(phone=phone).exists():
#             messages.error(request, "This phone number is already registered.")
#             return redirect('register')

#         # Create and save the new user
#         user = CustomUser(
#             username=username,
#             email=email,
#             phone=phone,
#             password=make_password(password)  # Hash the password
#         )
#         user.save()

#         messages.success(request, "Registration successful. You can now log in.")
#         return redirect('login')  # Redirect to login page after successful registration
